@echo off
rem One-shot sync for the notes repo. All ASCII on purpose.
git rm -r --ignore-unmatch docs/hackintosh docs/oci docs/misc docs/images docs/github-pat-token.md docs/troubleshooting-template.md README-ADDON.md
git add -A
git commit -m "refactor: per-post folders and auto index"
git push
echo.
echo Done. Press any key to close.
pause >nul
