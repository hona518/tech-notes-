@echo off
chcp 65001 >nul
rem Launch the notes tool with the built-in Windows PowerShell.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\notes-tool.ps1"
echo.
pause
