<!-- meta
title: Windows 下写 .md 不跑版的编辑器配置
category: 桌面工具
keywords: .md, Markdown 预览, VS Code 中文, 等宽字体, Notepad3, 排版错乱
slug: markdown-editor-setup
updated: 2026-11-23
-->

# Windows 下写 .md 不跑版的编辑器配置

> 关键词：`.md`、Markdown 预览、VS Code 中文、等宽字体、Notepad3、排版错乱、表格对不齐
>
> 分类：桌面工具 ｜ 首次记录：YYYY-MM-DD ｜ 最后验证：YYYY-MM-DD

## 症状 / 我要解决什么

双击 `.md` 打开是纯文本、表格对不齐；想要「左边写、右边看渲染结果」，并且界面是中文。

## 结论（先写答案）

用 VS Code 打开整个仓库文件夹：装中文语言包 + 用内置 Markdown 预览即可，不用另装格式转换工具，也不用先把 md 转成别的格式。

## 操作步骤

1. VS Code 里「文件 → 打开文件夹」，选本仓库根目录（这样侧边栏能直接看到所有笔记）
2. 中文界面：`Ctrl+Shift+P` → `Configure Display Language` → `zh-cn`（会提示装 Chinese Language Pack）
3. 整页预览：`Ctrl+Shift+V`；侧边预览：`Ctrl+K V`
4. 表格 / 中英文混排对齐：编辑器字体换成等宽的，别用比例字体
5. Notepad3 这类纯文本查看器只当速看，不当写作环境

## 踩过的坑

- 中英文混排表格对不齐 → 多半是字体问题，不是 Markdown 语法写错
- 直接双击 `.md` 被系统关联到记事本 → 右键「打开方式」改成 VS Code 并设为默认

## 验证方式

任意一篇 `.md` 在预览里表格、代码块、链接都渲染正常，`git push` 后网页显示一致。

## 关联

- [关键词速查表](KEYWORDS.md)
