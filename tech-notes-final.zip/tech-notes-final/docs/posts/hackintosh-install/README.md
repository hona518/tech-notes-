<!-- meta
title: 黑苹果安装流程记录（示例 / 按自己机型补全）
category: 黑苹果
keywords: OpenCore, config.plist, EFI, USB 定制, SMBIOS, OC 引导报错
slug: hackintosh-install
updated: 2026-11-23
-->

# 黑苹果安装流程记录（示例 / 按自己机型补全）

> 关键词：`OpenCore`、`config.plist`、`EFI`、USB 定制、`<机型>`、`<macOS 版本>`、`OC` 引导报错
>
> 分类：黑苹果 ｜ 首次记录：YYYY-MM-DD ｜ 最后验证：YYYY-MM-DD
> 适用环境：<CPU / 主板 / 显卡 / 无线网卡> + <macOS 版本> + OpenCore <版本>

## 症状 / 我要解决什么

从零装一套能稳定引导的系统，把可复用的 EFI 和踩坑点固化下来，下次不用重新查一遍。

## 结论（先写答案）

能稳定引导的最小组合是：`<引导版本>` + `<必要 kext 列表>` + `<SMBIOS 机型>`。最容易翻车的是 `<那一步>`。

## 环境（脱敏）

- 主板 / BIOS 版本：
- 序列号 / ROM / MLB / SystemUUID：一律写 `<SERIAL>` `<ROM>` `<MLB>` `<UUID>`，**不要写真值**
- BIOS 关键设置：`<CFG Lock / Above 4G / 显存 / 关闭串口……>`
- Apple ID、iMessage 相关标识：`<APPLE_ID>`

## 操作步骤

1. 制作安装盘 → `<工具 + 命令>`
2. 放置 EFI → `<分区 / 目录>`
3. 改 `config.plist` → `<关键项与取值>`
4. 首次引导 → `<用到的引导参数>`
5. 装后收尾：USB 定制、驱动、把引导从 U 盘迁到硬盘

```bash
# 示例：确认 EFI 分区挂载情况（按实际平台替换）
diskutil list
```

## 踩过的坑

- 现象 → 真实原因 → 怎么绕开
- 升级 OpenCore / macOS 后哪几项必须重查

## 验证方式

- 连续冷启动三次都能进系统
- 睡眠唤醒 / 音频 / 网卡 正常
- 截图、日志里不出现未打码的序列号与 Apple ID

## 关联

- [关键词速查表](KEYWORDS.md)
